import React, { useState, useEffect } from 'react';

const styles = {
  container: {
    width: '209.7vh',
    backgroundColor: '#000',
    color: '#fff',
    minHeight: '100vh',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
  },
  timeDisplay: {
    fontSize: '150px',
    fontWeight: 'bold',
  },
  controls: {
    marginTop: '20px',
    display: 'flex',
    justifyContent: 'space-between',
    width: '300px',
  },
  input: {
    
    padding: '5px 10px',
    borderRadius: '3px',
    fontSize: '16px',
  },
  button: {
    marginTop: "5px",
    padding: '5px 10px',
    borderRadius: '3px',
    cursor: 'pointer',
    backgroundColor: 'red',
    color: '#fff',
    fontSize: '16px',
  },
  currentTime: {
    marginTop: '40px',
    fontSize: '24px',
  },
};

function CountdownTimer() {
  const [time, setTime] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    let intervalId;
    if (isRunning) {
      intervalId = setInterval(() => {
        if (time === 0) {
          setIsRunning(false);
        } else {
          setTime((time) => time - 1);
        }
      }, 1000);
    }
    return () => clearInterval(intervalId);
  }, [time, isRunning]);

  useEffect(() => {
    const updateCurrentTime = () => {
      setCurrentTime(new Date());
    };
    const intervalId = setInterval(updateCurrentTime, 1000);
    return () => clearInterval(intervalId);
  }, []);

  const handleChange = (event) => {
    const newTime = parseInt(event.target.value);
    if (newTime >= 0) {
      setTime(newTime);
    }
  };

  const handleStart = () => {
    setIsRunning(true);
  };

  const handleStop = () => {
    setIsRunning(false);
  };

  const handleReset = () => {
    setTime(0);
    setIsRunning(false);
  };

  const getFormattedTime = () => {
    const seconds = Math.floor(time % 60);
    const minutes = Math.floor(time / 60) % 60;
    const hours = Math.floor(time / 3600);
    return `${hours}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  return (
    <div style={styles.container}>
      <div style={styles.timeDisplay}>{getFormattedTime()}</div>
      <div style={styles.controls}>
        <input style={styles.input} type="number" min="0" value={time} onChange={handleChange} />
        <button style={styles.button} onClick={handleStart}>
          Start
        </button>
        <button style={styles.button} onClick={handleStop}>
          Stop
        </button>
        <button style={styles.button} onClick={handleReset}>
          Reset
        </button>
      </div>
      <div style={styles.currentTime}>
        Current Time: {currentTime.toLocaleTimeString()}
      </div>
    </div>
  );
}

export default CountdownTimer;
